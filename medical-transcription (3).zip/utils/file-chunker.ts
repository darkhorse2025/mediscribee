/**
 * Utility function to split a large file into smaller chunks
 * This can be used to handle large audio files by sending them in chunks
 */
export function createFileChunks(file: File, chunkSize: number = 1024 * 1024): Blob[] {
  const chunks: Blob[] = []
  let start = 0

  while (start < file.size) {
    const end = Math.min(start + chunkSize, file.size)
    chunks.push(file.slice(start, end))
    start = end
  }

  return chunks
}

/**
 * Utility function to check if a file needs to be chunked
 */
export function shouldChunkFile(file: File, maxSize: number = 10 * 1024 * 1024): boolean {
  return file.size > maxSize
}

