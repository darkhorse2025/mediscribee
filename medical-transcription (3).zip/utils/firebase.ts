"use client"

import { initializeApp } from "firebase/app"
import { getFirestore, collection, addDoc, serverTimestamp } from "firebase/firestore"

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBe9a58zaQCrBSGeWwcIVa_PnZABoH6zV4",
  authDomain: "tudds-ccd0wn.firebaseapp.com",
  databaseURL: "https://tudds-ccd0wn-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "tudds-ccd0wn",
  storageBucket: "tudds-ccd0wn.appspot.com",
  messagingSenderId: "786974954352",
  appId: "1:786974954352:web:696d4fce818f14659bb5b5",
  measurementId: "G-CEQL4E8CW3",
}

// Initialize Firebase only on the client side
let app
let db

// Create a lazy initialization function that only runs on the client
const getFirebaseApp = () => {
  if (typeof window === "undefined") {
    throw new Error("Firebase can only be initialized on the client side")
  }

  if (!app) {
    try {
      app = initializeApp(firebaseConfig)
    } catch (error) {
      console.error("Error initializing Firebase app:", error)
      throw error
    }
  }
  return app
}

const getFirestoreDB = () => {
  if (typeof window === "undefined") {
    throw new Error("Firestore can only be initialized on the client side")
  }

  if (!db) {
    try {
      const app = getFirebaseApp()
      db = getFirestore(app)
    } catch (error) {
      console.error("Error initializing Firestore:", error)
      throw error
    }
  }
  return db
}

/**
 * Save medical scribe document to Firebase Firestore
 * @param htmlContent The HTML content of the medical scribe document
 * @param transcription The original transcription text
 * @returns Promise with the document reference
 */
export async function saveScriberDocumentToFirebase(htmlContent: string, transcription: string) {
  try {
    // Get Firestore instance (will throw if not on client)
    const db = getFirestoreDB()

    // Create a new document in the scribe_documents collection
    const docRef = await addDoc(collection(db, "scribe_documents"), {
      htmlContent,
      transcription,
      createdAt: serverTimestamp(),
    })

    console.log("Document saved to Firebase with ID:", docRef.id)
    return { success: true, docId: docRef.id }
  } catch (error) {
    console.error("Error saving document to Firebase:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error saving to Firebase",
    }
  }
}

