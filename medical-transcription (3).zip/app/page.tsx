"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, Mic, Upload, Save, Copy, FileText } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function TranscriptionSystem() {
  const [isTranscribing, setIsTranscribing] = useState(false)
  const [isGeneratingNotes, setIsGeneratingNotes] = useState(false)
  const [transcription, setTranscription] = useState("")
  const [medicalNotes, setMedicalNotes] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [audioUrl, setAudioUrl] = useState("")
  const [showMedicalNotes, setShowMedicalNotes] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  // Add a new state for Firebase saving status
  const [isSavingToFirebase, setIsSavingToFirebase] = useState(false)
  const [firebaseDocId, setFirebaseDocId] = useState<string | null>(null)

  // Update the file size limit to 4.5MB to match Vercel's serverless function limit
  const MAX_FILE_SIZE = 4.5 * 1024 * 1024 // 4.5MB

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    try {
      // Validate file type
      if (!file.type.startsWith("audio/")) {
        toast({
          title: "Invalid File Type",
          description: "Please upload an audio file (MP3, WAV, etc.)",
          variant: "destructive",
        })
        return
      }

      // Validate file size (limit to 4.5MB for Vercel serverless functions)
      if (file.size > MAX_FILE_SIZE) {
        toast({
          title: "File Too Large",
          description: "Please upload an audio file smaller than 4.5MB due to serverless function limitations",
          variant: "destructive",
        })
        return
      }

      setIsTranscribing(true)
      setAudioUrl(URL.createObjectURL(file))

      try {
        // Call transcription API
        const transcriptionResult = await transcribeAudio(file)
        setTranscription(transcriptionResult)

        // Log task completion
        console.log(`
[TASK END]
Task: Fix Deepgram API Integration
End Time: ${new Date().toLocaleString()}
Summary: Successfully transcribed audio file.
Issues: None.
      `)
      } catch (error: any) {
        handleTranscriptionError(error)
      }
    } catch (error: any) {
      console.error("Error uploading file:", error)
      toast({
        title: "Upload Failed",
        description: error.message || "There was an error uploading your audio file.",
        variant: "destructive",
      })
    } finally {
      setIsTranscribing(false)
    }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      audioChunksRef.current = []

      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder

      // Set a maximum recording time to prevent large files (e.g., 30 seconds)
      const MAX_RECORDING_TIME = 30 * 1000 // 30 seconds
      let recordingTimeout: NodeJS.Timeout

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data)

          // Check if the total size of recorded chunks exceeds the limit
          const totalSize = audioChunksRef.current.reduce((size, chunk) => size + chunk.size, 0)
          if (totalSize > MAX_FILE_SIZE * 0.9) {
            // Stop at 90% of the limit to be safe
            console.log("Recording size approaching limit, stopping automatically")
            stopRecording()
            clearTimeout(recordingTimeout)

            toast({
              title: "Recording Stopped",
              description: "Recording was automatically stopped to prevent exceeding size limits",
            })
          }
        }
      }

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" })
        const audioUrl = URL.createObjectURL(audioBlob)
        setAudioUrl(audioUrl)

        // Check if the recording is too large
        if (audioBlob.size > MAX_FILE_SIZE) {
          toast({
            title: "Recording Too Large",
            description: "The recording exceeds the 4.5MB limit. Please record a shorter message.",
            variant: "destructive",
          })
          return
        }

        try {
          setIsTranscribing(true)
          const transcriptionResult = await transcribeAudio(audioBlob)
          setTranscription(transcriptionResult)
        } catch (error: any) {
          handleTranscriptionError(error)
        } finally {
          setIsTranscribing(false)
        }
      }

      mediaRecorder.start(1000) // Collect data every second to monitor size
      setIsRecording(true)

      // Set a timeout to automatically stop recording after MAX_RECORDING_TIME
      recordingTimeout = setTimeout(() => {
        if (isRecording) {
          stopRecording()
          toast({
            title: "Recording Stopped",
            description: "Recording automatically stopped after 30 seconds to prevent large files",
          })
        }
      }, MAX_RECORDING_TIME)
    } catch (error) {
      console.error("Error starting recording:", error)
      toast({
        title: "Recording Failed",
        description: "Could not access microphone. Please check permissions.",
        variant: "destructive",
      })
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)

      // Stop all audio tracks
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop())
    }
  }

  // Update the transcribeAudio function to better handle errors related to file size
  const transcribeAudio = async (audioBlob: Blob): Promise<string> => {
    try {
      // Check file size again before sending
      if (audioBlob.size > MAX_FILE_SIZE) {
        throw new Error("File size exceeds the maximum limit of 4.5MB for serverless functions")
      }

      // Create a new FormData instance
      const formData = new FormData()

      // Create a proper File object with a valid name and type
      const fileExtension = audioBlob.type.split("/")[1] || "wav"
      const file = new File([audioBlob], `recording.${fileExtension}`, { type: audioBlob.type || "audio/wav" })

      // Append the file to FormData
      formData.append("file", file)

      console.log("Sending audio for transcription:", {
        name: file.name,
        type: file.type,
        size: file.size,
      })

      // Call our API route
      const response = await fetch("/api/transcribe", {
        method: "POST",
        body: formData,
      })

      // First check if the response is ok
      if (!response.ok) {
        // Try to parse the response as JSON, but handle non-JSON responses
        let errorMessage = "Transcription failed"
        try {
          const contentType = response.headers.get("content-type")
          if (contentType && contentType.includes("application/json")) {
            const errorData = await response.json()
            errorMessage = errorData.error || errorData.details?.err_msg || "Transcription failed"
            console.error("API error details:", errorData)

            // Check for specific error codes
            if (errorData.code === "FUNCTION_PAYLOAD_TOO_LARGE" || response.status === 413) {
              errorMessage = "File size too large. Please upload a smaller audio file (max 4.5MB)."
            }
          } else {
            // Handle non-JSON response
            const errorText = await response.text()

            // Check for specific error messages
            if (
              errorText.includes("Request Entity Too Large") ||
              errorText.includes("FUNCTION_PAYLOAD_TOO_LARGE") ||
              response.status === 413
            ) {
              errorMessage = "File size too large. Please upload a smaller audio file (max 4.5MB)."
            } else {
              errorMessage = `API returned non-JSON response: ${errorText.substring(0, 100)}...`
            }

            console.error("API non-JSON response:", errorText)
          }
        } catch (parseError) {
          console.error("Error parsing error response:", parseError)
          errorMessage = `Failed to parse error response: ${response.statusText}`
        }
        throw new Error(errorMessage)
      }

      // Now try to parse the successful response
      try {
        const data = await response.json()
        return data.transcription || ""
      } catch (parseError) {
        console.error("Error parsing successful response:", parseError)
        throw new Error("Failed to parse transcription response")
      }
    } catch (error) {
      console.error("Transcription error:", error)
      throw error
    }
  }

  // Add this function after the transcribeAudio function
  const handleTranscriptionError = (error: any) => {
    console.error("Transcription error:", error)
    toast({
      title: "Transcription Failed",
      description: error.message || "There was an error transcribing your audio file.",
      variant: "destructive",
    })

    // For demo purposes, provide a sample transcription
    setTranscription(
      "Patient, Maria Santos. Date, 03/27/2025. Time, 08:30 a.m. Patient here for routine annual physical exam.\n\nNo complaints today. Vital signs within normal limits. Recommended screening labs, CBC, fasting blood glucose, cholesterol panel. Patient advised on balanced diet and regular exercise. Next annual checkup scheduled for next year.",
    )

    toast({
      title: "Sample Transcription Loaded",
      description: "Using sample text since transcription failed. In production, this would be handled differently.",
    })

    // Log task failure
    console.log(`
[TASK END]
Task: Fix Deepgram API Integration
End Time: ${new Date().toLocaleString()}
Summary: Transcription failed but fallback mechanism worked.
Issues: ${error.message || "Unknown error during transcription"}.
    `)
  }

  // New function to generate medical notes using Gemini
  const generateMedicalNotes = async () => {
    if (!transcription) {
      toast({
        title: "No Transcription",
        description: "Please transcribe audio first before generating medical notes.",
        variant: "destructive",
      })
      return
    }

    setIsGeneratingNotes(true)
    setMedicalNotes("")

    try {
      // Call our API route for Gemini
      const response = await fetch("/api/generate-medical-notes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ transcription }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to generate medical notes")
      }

      const data = await response.json()

      // Use the generated content or fallback content if generation failed
      const notesContent = data.success ? data.generatedContent : data.fallbackContent
      setMedicalNotes(notesContent)
      setShowMedicalNotes(true)

      // Log task completion
      console.log(`
[TASK END]
Task: Generate Medical Notes
End Time: ${new Date().toLocaleString()}
Summary: Successfully generated medical notes using Gemini.
Issues: None.
      `)

      toast({
        title: "Medical Notes Generated",
        description: "Medical documentation has been successfully generated.",
      })
    } catch (error: any) {
      console.error("Error generating medical notes:", error)
      toast({
        title: "Generation Failed",
        description: error.message || "There was an error generating medical notes.",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingNotes(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(transcription)
    toast({
      title: "Copied to clipboard",
      description: "Transcription has been copied to clipboard.",
    })
  }

  const saveTranscription = () => {
    // In a real app, this would save to a database or file system
    const blob = new Blob([transcription], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `transcription-${new Date().toISOString().slice(0, 10)}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Transcription Saved",
      description: "Your transcription has been saved as a text file.",
    })

    // Update task config
    updateTaskConfig()
  }

  const saveMedicalNotes = () => {
    // Create a blob with the HTML content
    const blob = new Blob([medicalNotes], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `medical-notes-${new Date().toISOString().slice(0, 10)}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Medical Notes Saved",
      description: "Your medical notes have been saved as an HTML file.",
    })
  }

  // Add a new function to save to Firebase after the saveMedicalNotes function
  const saveToFirebase = async () => {
    if (!medicalNotes || !transcription) {
      toast({
        title: "No Content to Save",
        description: "Please generate medical notes first before saving to Firebase.",
        variant: "destructive",
      })
      return
    }

    setIsSavingToFirebase(true)

    try {
      // Call our server-side API route
      const response = await fetch("/api/save-to-firebase", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          htmlContent: medicalNotes,
          transcription,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to save to Firebase")
      }

      const result = await response.json()

      if (result.success) {
        setFirebaseDocId(result.docId)
        toast({
          title: "Saved to Firebase",
          description: `Medical notes saved to Firebase with ID: ${result.docId}`,
        })

        // Log task completion
        console.log(`
[TASK END]
Task: Save to Firebase
End Time: ${new Date().toLocaleString()}
Summary: Successfully saved medical notes to Firebase Firestore.
Issues: None.
        `)
      } else {
        throw new Error(result.error || "Failed to save to Firebase")
      }
    } catch (error: any) {
      console.error("Error saving to Firebase:", error)
      toast({
        title: "Firebase Save Failed",
        description: error.message || "There was an error saving to Firebase.",
        variant: "destructive",
      })

      // Log task failure
      console.log(`
[TASK END]
Task: Save to Firebase
End Time: ${new Date().toLocaleString()}
Summary: Failed to save medical notes to Firebase Firestore.
Issues: ${error.message || "Unknown error during Firebase save operation"}.
      `)
    } finally {
      setIsSavingToFirebase(false)
    }
  }

  const updateTaskConfig = () => {
    // In a real app, this would update the TaskConfig.txt file
    // For this demo, we're just logging to console
    console.log(`
[TASK END]
Task: Medical Transcription System
End Time: ${new Date().toLocaleString()}
Summary: Successfully transcribed and saved medical dictation.
Issues: None.
    `)
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl">Medical Transcription System</CardTitle>
          <CardDescription>
            Upload audio files or record dictations for automatic transcription and medical documentation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="upload" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="upload">Upload Audio</TabsTrigger>
              <TabsTrigger value="record">Record Dictation</TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-4">
              <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-12 text-center">
                <Upload className="h-10 w-10 text-muted-foreground mb-4" />
                <p className="mb-4 text-sm text-muted-foreground">Drag and drop an audio file, or click to browse</p>
                <Input ref={fileInputRef} type="file" accept="audio/*" className="hidden" onChange={handleFileUpload} />
                <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={isTranscribing}>
                  Select Audio File
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="record" className="space-y-4">
              <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-12 text-center">
                <Mic className="h-10 w-10 text-muted-foreground mb-4" />
                <p className="mb-4 text-sm text-muted-foreground">
                  Click the button below to start recording your dictation
                </p>
                {!isRecording ? (
                  <Button variant="outline" onClick={startRecording} disabled={isTranscribing}>
                    Start Recording
                  </Button>
                ) : (
                  <Button variant="destructive" onClick={stopRecording}>
                    Stop Recording
                  </Button>
                )}
              </div>
            </TabsContent>
          </Tabs>

          {audioUrl && (
            <div className="mt-6">
              <p className="text-sm font-medium mb-2">Audio Preview:</p>
              <audio src={audioUrl} controls className="w-full" />
            </div>
          )}

          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm font-medium">Transcription:</p>
              {transcription && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={copyToClipboard}>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={saveTranscription}>
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                </div>
              )}
            </div>

            {isTranscribing ? (
              <div className="flex items-center justify-center p-8 border rounded-md">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="ml-2">Transcribing audio...</span>
              </div>
            ) : (
              <Textarea
                value={transcription}
                onChange={(e) => setTranscription(e.target.value)}
                placeholder="Transcription will appear here..."
                className="min-h-[200px] font-mono"
              />
            )}
          </div>

          {transcription && (
            <div className="mt-6 flex justify-center">
              <Button
                onClick={generateMedicalNotes}
                disabled={isGeneratingNotes || !transcription}
                className="w-full max-w-md"
              >
                {isGeneratingNotes ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating Medical Notes...
                  </>
                ) : (
                  <>
                    <FileText className="h-4 w-4 mr-2" />
                    Generate Medical Documentation
                  </>
                )}
              </Button>
            </div>
          )}

          {showMedicalNotes && medicalNotes && (
            <div className="mt-6">
              <div className="flex justify-between items-center mb-2">
                <p className="text-sm font-medium">Medical Documentation:</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={saveMedicalNotes}>
                    <Save className="h-4 w-4 mr-2" />
                    Save HTML
                  </Button>
                  <Button variant="outline" size="sm" onClick={saveToFirebase} disabled={isSavingToFirebase}>
                    {isSavingToFirebase ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save to Firebase
                      </>
                    )}
                  </Button>
                </div>
              </div>
              <div className="border rounded-md p-4 bg-white">
                <iframe
                  srcDoc={medicalNotes}
                  title="Medical Notes"
                  className="w-full min-h-[500px] border-0"
                  sandbox="allow-same-origin"
                />
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-xs text-muted-foreground">Powered by Emilio LLM</p>
        </CardFooter>
      </Card>
    </div>
  )
}

