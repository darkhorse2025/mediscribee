import { type NextRequest, NextResponse } from "next/server"
import { initFirebaseAdmin } from "@/utils/firebase-admin"

export async function POST(request: NextRequest) {
  try {
    const { htmlContent, transcription } = await request.json()

    if (!htmlContent || !transcription) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Initialize Firebase Admin SDK (server-side)
    const db = initFirebaseAdmin()

    // Add document to Firestore
    const docRef = await db.collection("scribe_documents").add({
      htmlContent,
      transcription,
      createdAt: new Date(),
    })

    return NextResponse.json({
      success: true,
      docId: docRef.id,
    })
  } catch (error) {
    console.error("Error saving to Firebase:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

