import { type NextRequest, NextResponse } from "next/server"

export const config = {
  api: {
    bodyParser: false, // Disable the built-in bodyParser to handle streaming
    responseLimit: false, // Remove the response size limit
  },
}

export async function POST(request: NextRequest) {
  try {
    // Check content length to provide early feedback
    const contentLength = request.headers.get("content-length")
    if (contentLength && Number.parseInt(contentLength) > 4.5 * 1024 * 1024) {
      // 4.5MB limit for Vercel serverless functions
      return NextResponse.json(
        {
          error: "File too large",
          details: "Maximum file size is 4.5MB due to serverless function limitations",
          code: "FUNCTION_PAYLOAD_TOO_LARGE",
        },
        { status: 413 },
      )
    }

    const formData = await request.formData()
    const audioFile = formData.get("file") as File

    if (!audioFile) {
      return NextResponse.json({ error: "No audio file provided" }, { status: 400 })
    }

    // Log file details for debugging
    console.log("Received file:", {
      fileName: audioFile.name,
      fileType: audioFile.type,
      fileSize: audioFile.size,
    })

    // Check file size again after receiving the file
    if (audioFile.size > 4.5 * 1024 * 1024) {
      // 4.5MB limit for Vercel serverless functions
      return NextResponse.json(
        {
          error: "File too large",
          details: "Maximum file size is 4.5MB due to serverless function limitations",
          code: "FUNCTION_PAYLOAD_TOO_LARGE",
        },
        { status: 413 },
      )
    }

    // Convert the file to ArrayBuffer
    const arrayBuffer = await audioFile.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Make sure we have the API key
    const apiKey = process.env.DEEPGRAM_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: "Deepgram API key not configured" }, { status: 500 })
    }

    // Call Deepgram API with the buffer directly
    const response = await fetch("https://api.deepgram.com/v1/listen?smart_format=true&punctuate=true&diarize=true", {
      method: "POST",
      headers: {
        Authorization: `Token ${apiKey}`,
        "Content-Type": audioFile.type || "audio/wav", // Use the file's content type or default to audio/wav
      },
      body: buffer,
    })

    // Check if the response is ok
    if (!response.ok) {
      // Try to get the error message, but handle non-JSON responses
      let errorDetails = "Unknown error"
      try {
        // Check content type to see if it's JSON
        const contentType = response.headers.get("content-type")
        if (contentType && contentType.includes("application/json")) {
          const errorData = await response.json()
          errorDetails = errorData
          console.error("Deepgram API error details (JSON):", errorData)
        } else {
          // Handle non-JSON response
          const errorText = await response.text()
          errorDetails = errorText
          console.error("Deepgram API error details (Text):", errorText)
        }
      } catch (parseError) {
        console.error("Error parsing error response:", parseError)
        // If we can't parse the response, just use the status text
        errorDetails = response.statusText
      }

      return NextResponse.json(
        {
          error: "Failed to transcribe audio",
          details: errorDetails,
          status: response.status,
        },
        { status: response.status },
      )
    }

    // Check content type to ensure we're getting JSON
    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      const textResponse = await response.text()
      console.error("Unexpected non-JSON response:", textResponse)
      return NextResponse.json(
        {
          error: "Unexpected response format from Deepgram API",
          details: textResponse.substring(0, 200) + "...", // Truncate long responses
        },
        { status: 500 },
      )
    }

    // Parse JSON response
    const data = await response.json()

    // Extract transcription from Deepgram response
    const transcription = data.results?.channels[0]?.alternatives[0]?.transcript || ""

    return NextResponse.json({ transcription })
  } catch (error) {
    console.error("Transcription error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

