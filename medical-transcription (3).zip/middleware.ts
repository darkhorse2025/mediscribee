import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Check if this is a POST request to the transcribe API
  if (request.nextUrl.pathname === "/api/transcribe" && request.method === "POST") {
    // Check content length header
    const contentLength = request.headers.get("content-length")

    // If content length is greater than 4.5MB (Vercel's limit), return an error
    if (contentLength && Number.parseInt(contentLength) > 4.5 * 1024 * 1024) {
      return NextResponse.json(
        {
          error: "File too large",
          details: "Maximum file size is 4.5MB due to serverless function limitations",
          code: "FUNCTION_PAYLOAD_TOO_LARGE",
        },
        { status: 413 },
      )
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: "/api/transcribe",
}

