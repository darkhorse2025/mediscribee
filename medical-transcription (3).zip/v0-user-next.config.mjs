/** @type {import('next').NextConfig} */
const baseConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  experimental: {
    webpackBuildWorker: true,
    parallelServerBuildTraces: true,
    parallelServerCompiles: true,
  },
};

// Import user config
import v0UserConfig from './v0-user-next.config.mjs';

const nextConfig = {
  ...baseConfig,
  ...v0UserConfig,
};

export default nextConfig;

