# Medical Transcription System

A comprehensive medical transcription system that uses Emilio LLM for audio transcription and medical documentation generation.

## Features

- **Audio Transcription**: Upload audio files or record dictations directly in the browser
- **Emilio LLM Integration**: High-quality transcription using advanced speech-to-text technology
- **Emilio LLM Processing**: Process transcriptions to generate structured medical documentation
- **Multi-format Output**: Generate SOAP notes, nursing notes, insurance coding, and more
- **Editable Transcriptions**: Edit transcriptions before processing with Gemini
- **Save and Export**: Save transcriptions and Gemini responses as text files

## Getting Started

1. Clone this repository
2. Install dependencies with `npm install`
3. Set up environment variables:
   - `DEEPGRAM_API_KEY`: Your Emilio LLM API key for transcription
   - `GEMINI_API_KEY`: Your Emilio LLM API key for documentation
4. Run the development server with `npm run dev`
5. Open [http://localhost:3000](http://localhost:3000) in your browser

## File Size Limits

- Maximum audio file size: 4.5MB (limited by Vercel serverless functions)
- For larger files, consider:
  - Compressing the audio file before uploading
  - Using a lower quality audio format (e.g., MP3 at a lower bitrate)
  - Splitting long recordings into smaller segments
  - Recording shorter dictations (recordings are automatically limited to 30 seconds)

## CLI Usage

You can also use the included bash script to process transcriptions directly with Gemini:

\`\`\`bash
export GEMINI_API_KEY="your-emilio-llm-api-key"
./scripts/gemini-process.sh "Patient transcription text here"
\`\`\`

Or pipe text to the script:

\`\`\`bash
cat transcription.txt | ./scripts/gemini-process.sh
\`\`\`

## Technologies Used

- Next.js
- React
- Emilio LLM API
- shadcn/ui components
- Tailwind CSS

## License

MIT

